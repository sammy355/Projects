package com.example.dtc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    public EditText bus;
    public EditText route;
    public EditText fare;
    public EditText fare2;
    public EditText bookingTime;
    public EditText tick;
    public EditText startStop;
    public EditText endStop;
    Button blue,red,green,orange;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //initialisation
        bus=findViewById(R.id.bname);
        route=findViewById(R.id.route);
        fare=findViewById(R.id.fare);
        fare2=findViewById(R.id.fareafter);
        bookingTime=findViewById(R.id.timebooked);
        tick=findViewById(R.id.tickets);
        startStop=findViewById(R.id.starting);
        endStop=findViewById(R.id.ending);
        blue=findViewById(R.id.blueButton);
        red=findViewById(R.id.redButton);
        green=findViewById(R.id.greenButton);
        orange=findViewById(R.id.orangeButton);
        //end

        blue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String bname = bus.getText().toString();
                String rname = route.getText().toString();
                String fone = fare.getText().toString();
                String ftwo = fare2.getText().toString();
                String btime = bookingTime.getText().toString();
                String nt = tick.getText().toString();
                String ss = startStop.getText().toString();
                String es = endStop.getText().toString();
                Intent in = new Intent(MainActivity.this,heistBlue.class);
                in.putExtra("busName",bname);
                in.putExtra("routeName",rname);
                in.putExtra("fare",fone);
                in.putExtra("fare2",ftwo);
                in.putExtra("bookingTime",btime);
                in.putExtra("tickets",nt);
                in.putExtra("startStop",ss);
                in.putExtra("endStop",es);
                startActivity(in);
            }
        });

        red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String bname = bus.getText().toString();
                String rname = route.getText().toString();
                String fone = fare.getText().toString();
                String ftwo = fare2.getText().toString();
                String btime = bookingTime.getText().toString();
                String nt = tick.getText().toString();
                String ss = startStop.getText().toString();
                String es = endStop.getText().toString();
                Intent in = new Intent(MainActivity.this,heistRed.class);
                in.putExtra("busName",bname);
                in.putExtra("routeName",rname);
                in.putExtra("fare",fone);
                in.putExtra("fare2",ftwo);
                in.putExtra("bookingTime",btime);
                in.putExtra("tickets",nt);
                in.putExtra("startStop",ss);
                in.putExtra("endStop",es);
                startActivity(in);
            }
        });

        green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String bname = bus.getText().toString();
                String rname = route.getText().toString();
                String fone = fare.getText().toString();
                String ftwo = fare2.getText().toString();
                String btime = bookingTime.getText().toString();
                String nt = tick.getText().toString();
                String ss = startStop.getText().toString();
                String es = endStop.getText().toString();
                Intent in = new Intent(MainActivity.this,heistGreen.class);
                in.putExtra("busName",bname);
                in.putExtra("routeName",rname);
                in.putExtra("fare",fone);
                in.putExtra("fare2",ftwo);
                in.putExtra("bookingTime",btime);
                in.putExtra("tickets",nt);
                in.putExtra("startStop",ss);
                in.putExtra("endStop",es);
                startActivity(in);
            }
        });

        orange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String bname = bus.getText().toString();
                String rname = route.getText().toString();
                String fone = fare.getText().toString();
                String ftwo = fare2.getText().toString();
                String btime = bookingTime.getText().toString();
                String nt = tick.getText().toString();
                String ss = startStop.getText().toString();
                String es = endStop.getText().toString();
                Intent in = new Intent(MainActivity.this,heistOrange.class);
                in.putExtra("busName",bname);
                in.putExtra("routeName",rname);
                in.putExtra("fare",fone);
                in.putExtra("fare2",ftwo);
                in.putExtra("bookingTime",btime);
                in.putExtra("tickets",nt);
                in.putExtra("startStop",ss);
                in.putExtra("endStop",es);
                startActivity(in);
            }
        });

    }
}