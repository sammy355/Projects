package com.example.dtc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class heistRed extends AppCompatActivity {
    public TextView bus;
    public TextView fare1;
    public TextView fare2;
    public TextView route;
    public TextView ticket;
    public TextView btime;
    public TextView sstop;
    public TextView estop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heist_red);
        //initialisation
        bus=findViewById(R.id.bus);
        fare1=findViewById(R.id.fare1);
        fare2=findViewById(R.id.fare2);
        route=findViewById(R.id.rname);
        ticket=findViewById(R.id.nt);
        btime=findViewById(R.id.bookTime);
        sstop=findViewById(R.id.ss);
        estop=findViewById(R.id.es);
        //end

        String bname = getIntent().getStringExtra("busName");
        String rname = getIntent().getStringExtra("routeName");
        String f1 = getIntent().getStringExtra("fare");
        String f2 = getIntent().getStringExtra("fare2");
        String bt = getIntent().getStringExtra("bookingTime");
        String tick = getIntent().getStringExtra("tickets");
        String ss = getIntent().getStringExtra("startStop");
        String es = getIntent().getStringExtra("endStop");

        //setting texts
        bus.setText(bname);
        fare1.setText("₹"+f1);
        fare2.setText("₹"+f2);
        route.setText(rname);
        ticket.setText(tick);
        btime.setText(bt);
        sstop.setText(ss);
        estop.setText(es);
        //end
    }
}