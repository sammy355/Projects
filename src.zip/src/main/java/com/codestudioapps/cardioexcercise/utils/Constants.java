package com.codestudioapps.cardioexcercise.utils;

public class Constants {
    public static String KEY_language = "language";
    public static String KEY_prev_phone_lang = "prev_phone_lang";
    public static String KEY_remove_ad = "remove_ad";
    public static String Loopbots_sharedpreference = "Loopbots";





    public static String KEY_PROGRESS = "Progress";
    public static long READY_TO_GO_TIMT = 10;
    public static int REST_TIME = 30;
    public static int TOTAL_DAYS = 30;
}
