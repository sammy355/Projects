package com.codestudioapps.cardioexcercise;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;

/* compiled from: lambda */
public final /* synthetic */ class h implements MaterialDialog.SingleButtonCallback {


    public static final /* synthetic */ h f7a = new h();

    private /* synthetic */ h() {
    }

    public final void onClick(MaterialDialog materialDialog, DialogAction dialogAction) {
        materialDialog.dismiss();
    }
}
